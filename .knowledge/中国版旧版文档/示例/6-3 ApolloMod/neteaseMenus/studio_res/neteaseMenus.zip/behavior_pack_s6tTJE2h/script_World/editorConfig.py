# -*- coding: utf-8 -*-
isUnique = True
LastVersion = [
	0,
	0,
	2
]
compId = 'World'
version = [
	0,
	0,
	2
]
dataDict = {
	'9c301b3f-de66-4011-9d7f-2c06bf2cfc3a': {
		'cheat': True,
		'cheatInfo': {
			'command_blocks_enabled': True,
			'daylight_cycle': False,
			'entities_drop_loot': True,
			'keep_inventory': False,
			'mob_griefing': True,
			'mob_spawn': False,
			'random_tick_speed': 1,
			'stable_time': 6000,
			'weather_cycle': False
		},
		'difficulty': 1,
		'gameMode': 0,
		'isCreate': False,
		'levelId': '',
		'optionInfo': {
			'experimental_gameplay': False,
			'fire_spreads': True,
			'mob_loot': True,
			'natural_regeneration': True,
			'pvp': True,
			'show_coordinates': True,
			'tile_drops': True,
			'tnt_explodes': True
		},
		'spawn': [
			0,
			0,
			0
		],
		'storyline': '',
		'title': 'neteaseMenus',
		'uuid': '9c301b3f-de66-4011-9d7f-2c06bf2cfc3a'
	}
}
scriptFolderName = 'script_World'
